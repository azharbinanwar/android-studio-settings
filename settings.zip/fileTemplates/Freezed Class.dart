part '${FILE_NAME}.freezed.dart';
part '${FILE_NAME}.g.dart';

@freezed
class ${NAME} with _$${NAME} {
const factory ${NAME}() = _${NAME};
factory ${NAME}.fromJson(Map<String, dynamic> json) => _\$${NAME}FromJson(json);
}